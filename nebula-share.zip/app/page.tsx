"use client"

import { useState, useEffect } from "react"
import { HostStatusBar } from "@/components/host-status-bar"
import { ZoneNavigation, type Zone } from "@/components/zone-navigation"
import { FileHub } from "@/components/file-hub"
import { NetworkHub } from "@/components/network-hub"
import { IntelligenceCenter } from "@/components/intelligence-center"
import { ThemeToggle } from "@/components/theme-toggle"

export default function NebulaShareDashboard() {
  const [activeZone, setActiveZone] = useState<Zone>("files")

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey) {
        switch (e.key) {
          case "1":
            e.preventDefault()
            setActiveZone("files")
            break
          case "2":
            e.preventDefault()
            setActiveZone("network")
            break
          case "3":
            e.preventDefault()
            setActiveZone("intelligence")
            break
        }
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [])

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Persistent Host Status Bar */}
      <HostStatusBar />

      {/* Main Content */}
      <main className="flex-1 flex flex-col">
        {/* Header */}
        <header className="px-4 sm:px-8 pt-7 pb-5 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-9 h-9 rounded-xl bg-foreground flex items-center justify-center">
              <span className="text-background font-semibold text-sm">N</span>
            </div>
            <div className="hidden lg:block">
              <h1 className="text-[17px] font-semibold tracking-tight leading-none">NebulaShare</h1>
              <p className="text-xs text-muted-foreground mt-1.5">星云互传 · AW 的指挥中心</p>
            </div>
          </div>

          {/* Zone Navigation */}
          <ZoneNavigation activeZone={activeZone} onZoneChange={setActiveZone} />

          {/* Right cluster: theme toggle + user */}
          <div className="flex items-center gap-2 shrink-0">
            <ThemeToggle />
            <div className="w-px h-5 bg-border hidden sm:block" />
            <div className="text-right hidden sm:block">
              <p className="text-sm font-medium leading-none">AW</p>
              <p className="text-xs text-muted-foreground mt-1.5">管理员</p>
            </div>
            <div className="relative w-9 h-9 rounded-full bg-secondary flex items-center justify-center text-secondary-foreground font-semibold text-xs">
              AW
              <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-success border-2 border-background" />
            </div>
          </div>
        </header>

        {/* Zone Content */}
        <div className="flex-1 px-4 sm:px-8 pb-8">
          <div className="h-full min-h-[calc(100vh-220px)] bg-card rounded-2xl shadow-card p-5 sm:p-8">
            <div key={activeZone} className="animate-zone-in h-full">
              {activeZone === "files" && <FileHub />}
              {activeZone === "network" && <NetworkHub />}
              {activeZone === "intelligence" && <IntelligenceCenter />}
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="px-4 sm:px-8 py-4 flex items-center justify-between text-xs text-muted-foreground">
        <div className="flex items-center gap-3">
          <span>NebulaShare v2.0</span>
          <span className="hidden sm:inline text-border">·</span>
          <span className="hidden sm:inline">Raspberry Pi 4B</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-success animate-pulse-soft" />
          <span>系统正常</span>
        </div>
      </footer>
    </div>
  )
}

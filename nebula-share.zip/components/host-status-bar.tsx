"use client"

import { useState } from "react"
import { ChevronDown, X, Search } from "lucide-react"
import { cn } from "@/lib/utils"

interface Process {
  pid: number
  name: string
  cpu: number
  memory: number
  runtime: string
}

const mockProcesses: Process[] = [
  { pid: 1, name: "systemd", cpu: 0.1, memory: 0.5, runtime: "7d 12h" },
  { pid: 234, name: "nginx", cpu: 1.2, memory: 2.1, runtime: "7d 12h" },
  { pid: 456, name: "node", cpu: 12.5, memory: 8.3, runtime: "3d 4h" },
  { pid: 789, name: "python3", cpu: 3.2, memory: 4.1, runtime: "1d 2h" },
  { pid: 1024, name: "clash", cpu: 5.8, memory: 3.2, runtime: "7d 12h" },
  { pid: 1234, name: "docker", cpu: 2.1, memory: 15.2, runtime: "7d 12h" },
  { pid: 1456, name: "postgres", cpu: 1.5, memory: 6.8, runtime: "5d 8h" },
  { pid: 1678, name: "redis", cpu: 0.8, memory: 1.2, runtime: "7d 12h" },
]

export function HostStatusBar() {
  const [isExpanded, setIsExpanded] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")

  const stats = {
    cpu: 12,
    memory: "4.2GB",
    temp: 42,
    up: "2.1",
    down: "15.3",
    diskUsed: 156,
    diskTotal: 256,
    uptime: "7 天 12 小时",
  }

  const filteredProcesses = mockProcesses.filter((p) =>
    p.name.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="relative">
      {/* Main Status Bar — full width, hairline divider beneath */}
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className={cn(
          "w-full flex items-center justify-center gap-x-3 px-4 sm:px-8 h-11",
          "border-b border-border bg-background/80 backdrop-blur-sm",
          "hover:bg-secondary/40 transition-colors cursor-pointer",
        )}
      >
        {/* Live dot */}
        <span className="w-1.5 h-1.5 rounded-full bg-success animate-pulse-soft shrink-0" />

        {/* Inline metrics, monospace numbers */}
        <div className="flex items-center gap-x-2 text-[13px] text-muted-foreground font-mono overflow-x-auto whitespace-nowrap">
          <span>
            CPU <span className="text-foreground">{stats.cpu}%</span>
          </span>
          <span className="text-border">·</span>
          <span>
            RAM <span className="text-foreground">{stats.memory}</span>
          </span>
          <span className="text-border">·</span>
          <span>
            <span className="text-foreground">{stats.temp}°C</span>
          </span>
          <span className="text-border">·</span>
          <span className="inline-flex items-center gap-1">
            <span aria-hidden>↑</span>
            <span className="text-foreground">{stats.up}</span>
            <span aria-hidden>↓</span>
            <span className="text-foreground">{stats.down}</span>
            <span className="text-muted-foreground/70">MB/s</span>
          </span>
        </div>

        <ChevronDown
          className={cn(
            "w-3.5 h-3.5 text-muted-foreground transition-transform shrink-0",
            isExpanded && "rotate-180",
          )}
          strokeWidth={1.5}
        />
      </button>

      {/* Expanded Panel */}
      {isExpanded && (
        <div className="absolute top-full left-0 right-0 z-50 bg-popover border-b border-border shadow-pop">
          <div className="p-4 sm:p-6 max-w-5xl mx-auto">
            {/* Header */}
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-medium">系统进程</h3>
                <p className="text-xs text-muted-foreground mt-0.5">在线时间 · {stats.uptime}</p>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  setIsExpanded(false)
                }}
                className="p-1.5 hover:bg-accent rounded-lg transition-colors"
              >
                <X className="w-4 h-4" strokeWidth={1.5} />
              </button>
            </div>

            {/* Search */}
            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
              <input
                type="text"
                placeholder="搜索进程"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-secondary/60 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-ring transition-shadow"
              />
            </div>

            {/* Process Table */}
            <div className="overflow-auto max-h-64">
              <table className="w-full text-[13px]">
                <thead>
                  <tr className="text-left text-muted-foreground">
                    <th className="pb-2 font-medium font-mono">PID</th>
                    <th className="pb-2 font-medium">进程名</th>
                    <th className="pb-2 font-medium text-right">CPU</th>
                    <th className="pb-2 font-medium text-right">内存</th>
                    <th className="pb-2 font-medium text-right">运行时间</th>
                    <th className="pb-2 font-medium text-right">操作</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredProcesses.map((process) => (
                    <tr key={process.pid} className="border-t border-border/60 hover:bg-secondary/40 transition-colors">
                      <td className="py-2 font-mono text-muted-foreground">{process.pid}</td>
                      <td className="py-2 font-mono">{process.name}</td>
                      <td className="py-2 text-right font-mono">
                        <span className={cn(process.cpu > 10 ? "text-warning" : "text-foreground")}>
                          {process.cpu.toFixed(1)}%
                        </span>
                      </td>
                      <td className="py-2 text-right font-mono text-muted-foreground">{process.memory.toFixed(1)}%</td>
                      <td className="py-2 text-right font-mono text-muted-foreground">{process.runtime}</td>
                      <td className="py-2 text-right">
                        <button className="px-2 py-1 text-xs text-destructive hover:bg-destructive/10 rounded-md transition-colors">
                          终止
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

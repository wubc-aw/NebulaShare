"use client"

import { useState } from "react"
import {
  Power,
  Wifi,
  Globe,
  ArrowUpDown,
  RefreshCw,
  Zap,
  Activity,
  Settings,
} from "lucide-react"
import { cn } from "@/lib/utils"

interface ProxyNode {
  id: string
  name: string
  latency: number | null
  type: string
}

interface ServiceStatus {
  name: string
  status: "online" | "offline" | "slow"
  latency: number | null
  httpCode: number | null
}

const mockNodes: ProxyNode[] = [
  { id: "1", name: "香港 01", latency: 45, type: "Shadowsocks" },
  { id: "2", name: "香港 02", latency: 62, type: "VMess" },
  { id: "3", name: "日本 01", latency: 89, type: "Trojan" },
  { id: "4", name: "新加坡 01", latency: 120, type: "VMess" },
  { id: "5", name: "美国 01", latency: 180, type: "Shadowsocks" },
  { id: "6", name: "台湾 01", latency: null, type: "VMess" },
]

const domesticServices: ServiceStatus[] = [
  { name: "微信", status: "online", latency: 12, httpCode: 200 },
  { name: "哔哩哔哩", status: "online", latency: 18, httpCode: 200 },
  { name: "淘宝", status: "online", latency: 25, httpCode: 200 },
  { name: "百度", status: "online", latency: 15, httpCode: 200 },
  { name: "抖音", status: "slow", latency: 350, httpCode: 200 },
]

const internationalServices: ServiceStatus[] = [
  { name: "Google", status: "online", latency: 89, httpCode: 200 },
  { name: "YouTube", status: "online", latency: 95, httpCode: 200 },
  { name: "GitHub", status: "online", latency: 120, httpCode: 200 },
  { name: "X/Twitter", status: "offline", latency: null, httpCode: null },
  { name: "ChatGPT", status: "online", latency: 145, httpCode: 200 },
]

function Tabs({
  tabs,
  active,
  onChange,
}: {
  tabs: { id: string; label: string }[]
  active: string
  onChange: (id: string) => void
}) {
  return (
    <div className="inline-flex items-center gap-0.5 rounded-xl bg-secondary/60 p-1">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => onChange(tab.id)}
          className={cn(
            "px-3.5 py-1.5 text-[13px] rounded-lg transition-colors",
            active === tab.id
              ? "bg-card text-foreground shadow-card"
              : "text-muted-foreground hover:text-foreground",
          )}
        >
          {tab.label}
        </button>
      ))}
    </div>
  )
}

function Panel({ children, className }: { children: React.ReactNode; className?: string }) {
  return <div className={cn("p-4 rounded-xl bg-secondary/30", className)}>{children}</div>
}

export function NetworkHub() {
  const [activeTab, setActiveTab] = useState<"gateway" | "monitor" | "speed">("gateway")
  const [gatewayEnabled, setGatewayEnabled] = useState(true)
  const [routingMode, setRoutingMode] = useState<"rule" | "global" | "direct">("rule")
  const [selectedNode, setSelectedNode] = useState("1")
  const [isRefreshing, setIsRefreshing] = useState(false)

  const handleRefresh = () => {
    setIsRefreshing(true)
    setTimeout(() => setIsRefreshing(false), 2000)
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-[17px] font-semibold tracking-tight">网络枢纽</h2>
          <p className="text-xs text-muted-foreground mt-1">网关、连通性与测速</p>
        </div>
        <Tabs
          tabs={[
            { id: "gateway", label: "网关控制" },
            { id: "monitor", label: "连通监测" },
            { id: "speed", label: "测速" },
          ]}
          active={activeTab}
          onChange={(id) => setActiveTab(id as "gateway" | "monitor" | "speed")}
        />
      </div>

      {activeTab === "gateway" && (
        <div className="flex-1 flex flex-col gap-3 overflow-auto cascade">
          {/* Gateway Status */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {/* Power Control */}
            <Panel>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Power className={cn("w-4 h-4", gatewayEnabled ? "text-success" : "text-muted-foreground")} strokeWidth={1.5} />
                  <span className="text-[13px] font-medium">代理服务</span>
                </div>
                <button
                  onClick={() => setGatewayEnabled(!gatewayEnabled)}
                  className={cn(
                    "w-10 h-5.5 rounded-full transition-colors relative",
                    gatewayEnabled ? "bg-success" : "bg-secondary",
                  )}
                  style={{ height: "1.375rem" }}
                >
                  <div
                    className={cn(
                      "absolute top-0.5 w-4 h-4 rounded-full bg-card shadow-card transition-transform",
                      gatewayEnabled ? "translate-x-[1.375rem]" : "translate-x-0.5",
                    )}
                  />
                </button>
              </div>
              <p className="text-xs text-muted-foreground">{gatewayEnabled ? "服务运行中" : "服务已停止"}</p>
            </Panel>

            {/* Traffic Stats */}
            <Panel>
              <div className="flex items-center gap-2 mb-3">
                <ArrowUpDown className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
                <span className="text-[13px] font-medium">实时流量</span>
              </div>
              <div className="flex items-center gap-4">
                <div>
                  <p className="text-xs text-muted-foreground mb-0.5">上传</p>
                  <p className="text-lg font-mono">2.4<span className="text-xs text-muted-foreground ml-1">MB/s</span></p>
                </div>
                <div className="w-px h-8 bg-border" />
                <div>
                  <p className="text-xs text-muted-foreground mb-0.5">下载</p>
                  <p className="text-lg font-mono">15.8<span className="text-xs text-muted-foreground ml-1">MB/s</span></p>
                </div>
              </div>
            </Panel>

            {/* Current Node */}
            <Panel>
              <div className="flex items-center gap-2 mb-3">
                <Globe className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
                <span className="text-[13px] font-medium">当前节点</span>
              </div>
              <p className="text-[15px] font-medium">香港 01</p>
              <p className="text-xs text-muted-foreground font-mono mt-0.5">45ms · Shadowsocks</p>
            </Panel>
          </div>

          {/* Routing Mode */}
          <Panel>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Wifi className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
                <span className="text-[13px] font-medium">路由模式</span>
              </div>
              <button className="p-1.5 hover:bg-accent rounded-lg transition-colors">
                <Settings className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
              </button>
            </div>
            <div className="inline-flex items-center gap-0.5 rounded-lg bg-secondary/60 p-1 w-full">
              {(["rule", "global", "direct"] as const).map((mode) => (
                <button
                  key={mode}
                  onClick={() => setRoutingMode(mode)}
                  className={cn(
                    "flex-1 py-1.5 rounded-md text-[13px] transition-colors",
                    routingMode === mode ? "bg-card text-foreground shadow-card" : "text-muted-foreground hover:text-foreground",
                  )}
                >
                  {mode === "rule" && "规则分流"}
                  {mode === "global" && "全局代理"}
                  {mode === "direct" && "直连模式"}
                </button>
              ))}
            </div>
          </Panel>

          {/* Node Selector */}
          <Panel className="flex-1">
            <div className="flex items-center justify-between mb-3">
              <span className="text-[13px] font-medium">代理节点</span>
              <button onClick={handleRefresh} className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors">
                <RefreshCw className={cn("w-3.5 h-3.5", isRefreshing && "animate-spin")} strokeWidth={1.5} />
                刷新延迟
              </button>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {mockNodes.map((node) => {
                const isActive = selectedNode === node.id
                return (
                  <button
                    key={node.id}
                    onClick={() => setSelectedNode(node.id)}
                    className={cn(
                      "relative p-3 rounded-lg text-left transition-colors bg-card hover:bg-accent/60",
                    )}
                  >
                    {isActive && <span className="absolute left-0 top-2.5 bottom-2.5 w-0.5 rounded-full bg-chart-1" />}
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[13px] font-medium">{node.name}</span>
                      {node.latency ? (
                        <span
                          className={cn(
                            "text-xs font-mono",
                            node.latency < 100 ? "text-success" : node.latency < 200 ? "text-warning" : "text-destructive",
                          )}
                        >
                          {node.latency}ms
                        </span>
                      ) : (
                        <span className="text-xs text-muted-foreground font-mono">超时</span>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">{node.type}</p>
                  </button>
                )
              })}
            </div>
          </Panel>

          {/* Subscription */}
          <Panel>
            <div className="flex items-center justify-between mb-3">
              <span className="text-[13px] font-medium">订阅管理</span>
              <span className="text-xs text-muted-foreground font-mono">更新于 2 小时前</span>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="text"
                placeholder="订阅链接"
                className="flex-1 px-3 py-2 bg-card rounded-lg text-[13px] font-mono focus:outline-none focus:ring-1 focus:ring-ring transition-shadow"
                defaultValue="https://example.com/sub/***"
              />
              <button className="px-4 py-2 bg-foreground text-background rounded-lg text-[13px] font-medium hover:opacity-90 transition-opacity">
                更新
              </button>
            </div>
          </Panel>
        </div>
      )}

      {activeTab === "monitor" && (
        <div className="flex-1 flex flex-col gap-3 overflow-auto cascade">
          <div className="flex items-center justify-between">
            <h3 className="text-[13px] font-medium text-muted-foreground">服务连通性检测</h3>
            <button
              onClick={handleRefresh}
              className="flex items-center gap-2 px-3 py-1.5 bg-foreground text-background rounded-lg text-[13px] font-medium hover:opacity-90 transition-opacity"
            >
              <RefreshCw className={cn("w-3.5 h-3.5", isRefreshing && "animate-spin")} strokeWidth={1.5} />
              全部检测
            </button>
          </div>

          {/* Domestic Services */}
          <Panel>
            <h4 className="text-[13px] font-medium mb-3 flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-chart-3" />
              国内服务
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
              {domesticServices.map((service) => (
                <ServiceCard key={service.name} service={service} />
              ))}
            </div>
          </Panel>

          {/* International Services */}
          <Panel>
            <h4 className="text-[13px] font-medium mb-3 flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-chart-1" />
              国际服务
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
              {internationalServices.map((service) => (
                <ServiceCard key={service.name} service={service} />
              ))}
            </div>
          </Panel>
        </div>
      )}

      {activeTab === "speed" && (
        <div className="flex-1 flex flex-col gap-3 cascade">
          <SpeedTest />
        </div>
      )}
    </div>
  )
}

function statusColor(status: ServiceStatus["status"]) {
  if (status === "online") return "bg-success"
  if (status === "slow") return "bg-warning"
  return "bg-destructive"
}

function ServiceCard({ service }: { service: ServiceStatus }) {
  return (
    <div className="p-3 bg-card rounded-lg">
      <div className="flex items-center justify-between mb-2">
        <span className="text-[13px] font-medium truncate">{service.name}</span>
        <span className={cn("w-1.5 h-1.5 rounded-full shrink-0", statusColor(service.status))} />
      </div>
      <div className="flex items-center gap-2 font-mono">
        {service.latency ? (
          <span className="text-xs text-muted-foreground">{service.latency}ms</span>
        ) : (
          <span className="text-xs text-destructive">不可达</span>
        )}
        {service.httpCode && <span className="text-xs text-muted-foreground/60">{service.httpCode}</span>}
      </div>
    </div>
  )
}

function SpeedTest() {
  const [isRunning, setIsRunning] = useState(false)
  const [results, setResults] = useState({
    lan: { download: 0, upload: 0 },
    wan: { ping: 0, download: 0, upload: 0 },
  })

  const runTest = (type: "lan" | "wan") => {
    setIsRunning(true)
    setTimeout(() => {
      if (type === "lan") {
        setResults((prev) => ({ ...prev, lan: { download: 892, upload: 845 } }))
      } else {
        setResults((prev) => ({ ...prev, wan: { ping: 12, download: 95.4, upload: 48.2 } }))
      }
      setIsRunning(false)
    }, 3000)
  }

  const Metric = ({ label, value, unit }: { label: string; value: string | number; unit: string }) => (
    <div className="p-4 bg-card rounded-lg text-center">
      <p className="text-xs text-muted-foreground mb-1.5">{label}</p>
      <p className="text-2xl font-mono tracking-tight">{value}</p>
      <p className="text-xs text-muted-foreground/70 mt-0.5">{unit}</p>
    </div>
  )

  return (
    <>
      {/* LAN Speed Test */}
      <Panel>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
            <span className="text-[13px] font-medium">局域网测速</span>
          </div>
          <button
            onClick={() => runTest("lan")}
            disabled={isRunning}
            className="px-4 py-1.5 bg-foreground text-background rounded-lg text-[13px] font-medium hover:opacity-90 disabled:opacity-50 transition-opacity"
          >
            {isRunning ? "测试中" : "开始测试"}
          </button>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <Metric label="下载速度" value={results.lan.download || "--"} unit="MB/s" />
          <Metric label="上传速度" value={results.lan.upload || "--"} unit="MB/s" />
        </div>
      </Panel>

      {/* WAN Speed Test */}
      <Panel>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
            <span className="text-[13px] font-medium">互联网测速</span>
            <span className="text-xs text-muted-foreground/70">via speedtest.net</span>
          </div>
          <button
            onClick={() => runTest("wan")}
            disabled={isRunning}
            className="px-4 py-1.5 bg-foreground text-background rounded-lg text-[13px] font-medium hover:opacity-90 disabled:opacity-50 transition-opacity"
          >
            {isRunning ? "测试中" : "开始测试"}
          </button>
        </div>
        <div className="grid grid-cols-3 gap-2">
          <Metric label="Ping" value={results.wan.ping || "--"} unit="ms" />
          <Metric label="下载" value={results.wan.download || "--"} unit="Mbps" />
          <Metric label="上传" value={results.wan.upload || "--"} unit="Mbps" />
        </div>
      </Panel>
    </>
  )
}

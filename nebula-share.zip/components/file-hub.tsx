"use client"

import { useState, useCallback } from "react"
import {
  Upload,
  Download,
  Trash2,
  QrCode,
  Clock,
  File,
  FileText,
  FileImage,
  FileArchive,
  Folder,
  ChevronRight,
  HardDrive,
  Plus,
  MoreHorizontal,
} from "lucide-react"
import { cn } from "@/lib/utils"

interface UploadedFile {
  id: string
  name: string
  size: string
  uploadTime: string
  expiresIn: string
  type: "file" | "image" | "document" | "archive"
}

interface StorageDevice {
  id: string
  name: string
  type: "ssd" | "hdd"
  used: number
  total: number
}

const mockFiles: UploadedFile[] = [
  { id: "1", name: "screenshot_2026.png", size: "2.4 MB", uploadTime: "10 分钟前", expiresIn: "23 小时", type: "image" },
  { id: "2", name: "config.json", size: "4.2 KB", uploadTime: "1 小时前", expiresIn: "22 小时", type: "file" },
  { id: "3", name: "report.pdf", size: "1.8 MB", uploadTime: "3 小时前", expiresIn: "20 小时", type: "document" },
  { id: "4", name: "backup.zip", size: "156 MB", uploadTime: "昨天", expiresIn: "5 小时", type: "archive" },
]

const mockDevices: StorageDevice[] = [
  { id: "ssd", name: "内置 SSD", type: "ssd", used: 156, total: 256 },
  { id: "hdd", name: "外置 HDD", type: "hdd", used: 1.2, total: 4 },
]

const getFileIcon = (type: UploadedFile["type"]) => {
  switch (type) {
    case "image":
      return FileImage
    case "document":
      return FileText
    case "archive":
      return FileArchive
    default:
      return File
  }
}

function Tabs({
  tabs,
  active,
  onChange,
}: {
  tabs: { id: string; label: string }[]
  active: string
  onChange: (id: string) => void
}) {
  return (
    <div className="inline-flex items-center gap-0.5 rounded-xl bg-secondary/60 p-1">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => onChange(tab.id)}
          className={cn(
            "px-3.5 py-1.5 text-[13px] rounded-lg transition-colors",
            active === tab.id
              ? "bg-card text-foreground shadow-card"
              : "text-muted-foreground hover:text-foreground",
          )}
        >
          {tab.label}
        </button>
      ))}
    </div>
  )
}

export function FileHub() {
  const [activeTab, setActiveTab] = useState<"exchange" | "storage">("exchange")
  const [isDragging, setIsDragging] = useState(false)
  const [currentPath, setCurrentPath] = useState("/home/aw")
  const [selectedDevice, setSelectedDevice] = useState("ssd")

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback(() => setIsDragging(false), [])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }, [])

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-[17px] font-semibold tracking-tight">文件中心</h2>
          <p className="text-xs text-muted-foreground mt-1">快速交换与长期存储</p>
        </div>
        <Tabs
          tabs={[
            { id: "exchange", label: "快速交换" },
            { id: "storage", label: "长期存储" },
          ]}
          active={activeTab}
          onChange={(id) => setActiveTab(id as "exchange" | "storage")}
        />
      </div>

      {activeTab === "exchange" ? (
        <div className="flex-1 flex flex-col gap-5 cascade">
          {/* Upload Zone */}
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={cn(
              "relative rounded-xl p-12 text-center transition-colors",
              isDragging ? "dash-flow bg-secondary/40" : "bg-secondary/30",
            )}
          >
            {!isDragging && (
              <div className="absolute inset-0 rounded-xl border border-dashed border-border pointer-events-none" />
            )}
            <Upload
              className={cn("w-7 h-7 mx-auto mb-4", isDragging ? "text-foreground" : "text-muted-foreground")}
              strokeWidth={1.5}
            />
            <p className="text-sm text-muted-foreground mb-3">拖拽文件到这里，或者</p>
            <button className="px-4 py-1.5 bg-foreground text-background rounded-lg text-[13px] font-medium hover:opacity-90 transition-opacity">
              选择文件
            </button>
            <p className="text-xs text-muted-foreground/70 mt-4">文件将在 24 小时后自动删除</p>
          </div>

          {/* Storage Quota */}
          <div className="flex items-center justify-between py-3">
            <div className="flex items-center gap-2">
              <HardDrive className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
              <span className="text-[13px] text-muted-foreground">临时空间</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-32 h-1 bg-secondary rounded-full overflow-hidden">
                <div className="h-full bg-chart-1 rounded-full w-1/4" />
              </div>
              <span className="text-[13px] font-mono text-muted-foreground">256MB / 1GB</span>
            </div>
          </div>

          <div className="divider-x" />

          {/* File List */}
          <div className="flex-1 overflow-auto">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-[13px] font-medium text-muted-foreground">文件列表</h3>
              <button className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors">
                <QrCode className="w-3.5 h-3.5" strokeWidth={1.5} />
                生成二维码
              </button>
            </div>
            <div className="flex flex-col">
              {mockFiles.map((file, i) => {
                const Icon = getFileIcon(file.type)
                return (
                  <div
                    key={file.id}
                    className={cn(
                      "flex items-center justify-between py-3 group transition-colors rounded-lg px-2 -mx-2 hover:bg-secondary/50",
                      i !== 0 && "border-t border-border/60",
                    )}
                  >
                    <div className="flex items-center gap-3">
                      <Icon className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
                      <div>
                        <p className="text-[13px] font-medium">{file.name}</p>
                        <p className="text-xs text-muted-foreground font-mono mt-0.5">
                          {file.size} · {file.uploadTime}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-1 text-xs text-muted-foreground font-mono">
                        <Clock className="w-3 h-3" strokeWidth={1.5} />
                        {file.expiresIn}
                      </div>
                      <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button className="p-1.5 hover:bg-accent rounded-lg transition-colors">
                          <Download className="w-4 h-4" strokeWidth={1.5} />
                        </button>
                        <button className="p-1.5 hover:bg-destructive/10 text-destructive rounded-lg transition-colors">
                          <Trash2 className="w-4 h-4" strokeWidth={1.5} />
                        </button>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      ) : (
        <div className="flex-1 flex flex-col gap-5 cascade">
          {/* Device Selector */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {mockDevices.map((device) => {
              const isActive = selectedDevice === device.id
              return (
                <button
                  key={device.id}
                  onClick={() => setSelectedDevice(device.id)}
                  className={cn(
                    "relative p-4 rounded-xl text-left transition-colors bg-secondary/30 hover:bg-secondary/50",
                  )}
                >
                  {isActive && <span className="absolute left-0 top-4 bottom-4 w-0.5 rounded-full bg-chart-1" />}
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <HardDrive className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
                      <span className="text-[13px] font-medium">{device.name}</span>
                    </div>
                    <span className="text-[10px] font-mono uppercase text-muted-foreground tracking-wider">{device.type}</span>
                  </div>
                  <div className="w-full h-1 bg-secondary rounded-full overflow-hidden">
                    <div
                      className="h-full bg-chart-1 rounded-full"
                      style={{ width: `${(device.used / device.total) * 100}%` }}
                    />
                  </div>
                  <p className="text-xs text-muted-foreground font-mono mt-2">
                    {device.type === "hdd"
                      ? `${device.used} TB / ${device.total} TB`
                      : `${device.used} GB / ${device.total} GB`}
                  </p>
                </button>
              )
            })}
          </div>

          {/* Path Navigation */}
          <div className="flex items-center gap-2 py-1">
            <Folder className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
            {currentPath.split("/").filter(Boolean).map((segment, i, arr) => (
              <div key={i} className="flex items-center gap-2">
                <button
                  onClick={() => setCurrentPath("/" + arr.slice(0, i + 1).join("/"))}
                  className="text-[13px] font-mono text-muted-foreground hover:text-foreground transition-colors"
                >
                  {segment}
                </button>
                {i < arr.length - 1 && <ChevronRight className="w-3.5 h-3.5 text-muted-foreground/60" strokeWidth={1.5} />}
              </div>
            ))}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2">
            <button className="flex items-center gap-2 px-3 py-1.5 bg-foreground text-background rounded-lg text-[13px] font-medium hover:opacity-90 transition-opacity">
              <Upload className="w-4 h-4" strokeWidth={1.5} />
              上传
            </button>
            <button className="flex items-center gap-2 px-3 py-1.5 bg-secondary/60 rounded-lg text-[13px] hover:bg-secondary transition-colors">
              <Plus className="w-4 h-4" strokeWidth={1.5} />
              新建文件夹
            </button>
          </div>

          <div className="divider-x" />

          {/* File Browser */}
          <div className="flex-1 overflow-auto">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {["Documents", "Downloads", "Projects", "Backup"].map((folder) => (
                <button
                  key={folder}
                  className="p-4 bg-secondary/30 rounded-xl hover:bg-secondary/50 transition-colors text-left"
                >
                  <Folder className="w-7 h-7 text-muted-foreground mb-3" strokeWidth={1.5} />
                  <p className="text-[13px] font-medium">{folder}</p>
                  <p className="text-xs text-muted-foreground font-mono mt-0.5">12 项</p>
                </button>
              ))}
              {mockFiles.slice(0, 4).map((file) => {
                const Icon = getFileIcon(file.type)
                return (
                  <div
                    key={file.id}
                    className="p-4 bg-secondary/30 rounded-xl hover:bg-secondary/50 transition-colors group relative"
                  >
                    <Icon className="w-7 h-7 text-muted-foreground mb-3" strokeWidth={1.5} />
                    <p className="text-[13px] font-medium truncate">{file.name}</p>
                    <p className="text-xs text-muted-foreground font-mono mt-0.5">{file.size}</p>
                    <button className="absolute top-2 right-2 p-1 opacity-0 group-hover:opacity-100 hover:bg-accent rounded-md transition-all">
                      <MoreHorizontal className="w-4 h-4" strokeWidth={1.5} />
                    </button>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
